/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package server;

import com.sun.management.OperatingSystemMXBean;
import java.lang.management.ManagementFactory;
import javax.management.Attribute;
import javax.management.AttributeList;
import javax.management.MBeanServer;
import javax.management.ObjectName;

/**
 *
 * @author Hp
 */
public class Resources {
    
    public static double CPU_Usage(){
  
            /*
           OperatingSystemMXBean osbean= ManagementFactory.getPlatformMXBean(OperatingSystemMXBean.class);
            double pcl=osbean.getProcessCpuLoad();
           double spl= osbean.getSystemCpuLoad();
           
           
            System.out.println("CPU Process LOad:"+  ((int) (pcl * 1000) / 10.0));
            System.out.println("CPU  System LOad:"+((int) (spl * 1000) / 10.0) );

*/
            try {
            MBeanServer mbs = ManagementFactory.getPlatformMBeanServer();
            ObjectName name = ObjectName.getInstance("java.lang:type=OperatingSystem");
            AttributeList list = mbs.getAttributes(name, new String[]{"ProcessCpuLoad"});

            if (list.isEmpty()) {
                return Double.NaN;
            }

            Attribute att = (Attribute) list.get(0);
            Double value = (Double) att.getValue();

            // usually takes a couple of seconds before we get real values
            if (value == -1.0) {
                return Double.NaN;
            }
            // returns a percentage value with 1 decimal point precision
            return ((int) (value * 1000) / 10.0);
        } catch (Exception ex) {
            return 0;
        }
             }
   public static double Gbs(long s) {
        long sizekb = s / 1024;
        long sizemb = sizekb / 1024;
        long sizegb = sizemb / 1024;
        return sizegb;
    }

    public static String RAM_Usage() {
        long total_ram = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getTotalPhysicalMemorySize();
        long free_ram = ((com.sun.management.OperatingSystemMXBean) ManagementFactory.getOperatingSystemMXBean()).getFreePhysicalMemorySize();

        double Used_Ram = Gbs(total_ram) - Gbs(free_ram);
        return Used_Ram + "gb";
    }

}