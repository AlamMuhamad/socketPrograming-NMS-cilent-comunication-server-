/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package utility;

import java.time.LocalTime;
import java.time.format.DateTimeFormatter;

/**
 *
 * @author Hp
 */
public class Time {
    
    static public String GetTime() {
        LocalTime localTime = LocalTime.now();
        DateTimeFormatter dateTimeFormatter = DateTimeFormatter.ofPattern("hh:mm a");
        return localTime.format(dateTimeFormatter);
    }
}
    

